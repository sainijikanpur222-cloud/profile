import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Login.css';

export default function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const submit = (e) => {
    e.preventDefault();

    const next = {};

    if (!email.trim()) {
      next.email = 'Please enter your email address.';
    } else if (!/^\S+@\S+\.\S+$/.test(email)) {
      next.email = 'Enter a valid email address.';
    }

    if (!password) {
      next.password = 'Please enter your password.';
    } else if (password.length < 6) {
      next.password = 'Password must be at least 6 characters.';
    }

    setErrors(next);

    if (Object.keys(next).length) {
      return;
    }

    setLoading(true);

    setTimeout(() => {
      localStorage.setItem('isLoggedIn', 'true');
      navigate('/home');
    }, 700);
  };

  return (
    <div className="login-page">
      <div className="blob blob-one" />
      <div className="blob blob-two" />
      <div className="login-grid" />

      <section
        className="login-card"
        aria-label="Login"
      >
        <div className="brand-mark">S</div>

        <p className="eyebrow">SHIVA</p>

        <p className="login-kicker">
          Developer Portfolio
        </p>

        <h1>Welcome Back</h1>

        <p className="muted">
          Login to continue to my portfolio
        </p>

        <form onSubmit={submit} noValidate>
          <label>
            Email address

            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              type="email"
              aria-invalid={!!errors.email}
            />
          </label>

          {errors.email && (
            <small className="error">
              {errors.email}
            </small>
          )}

          <label>
            Password

            <span className="password-wrap">
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                type={show ? 'text' : 'password'}
                aria-invalid={!!errors.password}
              />

              <button
                type="button"
                onClick={() => setShow(!show)}
                aria-label={
                  show ? 'Hide password' : 'Show password'
                }
              >
                {show ? 'Hide' : 'Show'}
              </button>
            </span>
          </label>

          {errors.password && (
            <small className="error">
              {errors.password}
            </small>
          )}

          <div className="login-options">
            <label className="check">
              <input type="checkbox" />
              <span>Remember me</span>
            </label>

            <button
              type="button"
              className="text-link"
            >
              Forgot Password?
            </button>
          </div>

          <button
            className="primary login-submit"
            disabled={loading}
          >
            {loading ? (
              <>
                <i className="spinner" />
                Signing in…
              </>
            ) : (
              'Login'
            )}
          </button>
        </form>

        <div className="divider">
          <span>OR</span>
        </div>

        <div className="social-buttons">
          <button type="button">
            <b>G</b> Continue with Google
          </button>

          <button type="button">
            <b>⌘</b> Continue with GitHub
          </button>
        </div>

        <p className="login-foot">
          Welcome to my personal portfolio
        </p>
      </section>
    </div>
  );
}
import { useNavigate } from 'react-router-dom';
import '../styles/NotFound.css';

export default function NotFound() {
  const nav = useNavigate();
  return (
    <div className="nf-page">
      <div className="nf-glow" />
      <p className="nf-code">404</p>
      <h1>Page not found</h1>
      <p className="nf-sub">Looks like this route doesn't exist yet.</p>
      <button className="primary" onClick={() => nav('/home')}>
        Back to Home <b>↗</b>
      </button>
    </div>
  );
}

import { Navigate, Route, Routes } from 'react-router-dom';
import Login    from './pages/Login';
import Home     from './pages/Home';
import NotFound from './pages/NotFound';
import Cursor   from './components/Cursor';

function ProtectedRoute({ children }) {
  return localStorage.getItem('isLoggedIn') === 'true' ? (
    children
  ) : (
    <Navigate to="/login" replace />
  );
}

export default function App() {
  return (
    <>
      <Cursor />

      <Routes>
        <Route path="/login" element={<Login />} />

        <Route
          path="/home"
          element={
            <ProtectedRoute>
              <Home />
            </ProtectedRoute>
          }
        />

        <Route path="/404" element={<NotFound />} />

        <Route path="*" element={<Navigate to="/home" replace />} />
      </Routes>
    </>
  );
}

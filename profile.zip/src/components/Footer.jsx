import '../styles/Footer.css';

export default function Footer() {
  return (
    <footer>
      <a href="#home" className="footer-brand">
        SHIVA<span>.</span>
      </a>

      <p>© 2026 Shiva Saini. Built with React.</p>

      <div>
        <a href="#github">GitHub</a>
        <a href="#linkedin">LinkedIn</a>
        <a href="mailto:hello@example.com">Email</a>
      </div>
    </footer>
  );
}
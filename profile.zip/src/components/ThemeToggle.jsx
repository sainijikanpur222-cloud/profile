import { useEffect, useState } from 'react';
import '../styles/ThemeToggle.css';

export default function ThemeToggle() {
  const [light, setLight] = useState(
    () => localStorage.getItem('theme') === 'light'
  );

  useEffect(() => {
    document.body.classList.toggle('light', light);
    localStorage.setItem('theme', light ? 'light' : 'dark');
  }, [light]);

  return (
    <button
      className="theme-toggle"
      onClick={() => setLight((v) => !v)}
      aria-label="Toggle theme"
      title={light ? 'Switch to Dark' : 'Switch to Light'}
    >
      <span className="theme-track">
        <span className="theme-thumb">{light ? '☀' : '🌙'}</span>
      </span>
    </button>
  );
}

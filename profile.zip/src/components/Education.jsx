import '../styles/Education.css';

const timeline = [
  {
    period: '2025 — PRESENT',
    badge: 'CURRENT',
    title: 'Bachelor of Computer Applications',
    short: 'BCA',
    school: 'Allenhouse Business School',
    location: 'Kanpur, Uttar Pradesh',
    note: 'Developing a strong foundation in software development, web technologies and computer science fundamentals.',
    color: 'purple',
  },
  {
    period: '2024',
    badge: 'COMPLETED',
    title: 'Intermediate (12th)',
    short: '12th',
    school: 'S.N.S.D M I College',
    location: 'Uttar Pradesh Board',
    note: 'Completed senior secondary education with focus on science and mathematics.',
    color: 'cyan',
  },
];

const certifications = [
  { name: 'React — The Complete Guide',   issuer: 'Trainer',      icon: '⚛',  color: 'purple' },
  { name: 'C++ & DSA',  issuer: 'Trainer', icon: '📘', color: 'cyan'   },
  { name: 'Angular',   issuer: 'Trainer',      icon: '⚙',  color: 'green'  },
  { name: 'Git & GitHub Masterclass',     issuer: 'Coursera',   icon: '🛠',  color: 'yellow' },
  { name: 'Full-Stack Development',   issuer: 'Trainer',      icon: '🎗️',  color: 'purple' },
  { name:'Advance Excel', issuer:'Trainer', icon:"📘",color:'cyan'}
];

export default function Education() {
  return (
    <section id="education" className="section education">
      <div className="section-head center reveal">
        <p className="eyebrow">MY JOURNEY</p>
        <h2>Education <span>&amp; Growth</span></h2>
        <p>The path that shaped my skills and passion for development.</p>
      </div>

      {/* Timeline */}
      <div className="edu-timeline">
        <div className="edu-spine" />

        {timeline.map((item) => (
          <article className={`edu-card reveal ec-${item.color}`} key={item.title}>
            <div className="edu-dot" />

            <div className="edu-period">
              <span className={`edu-badge eb-${item.color}`}>{item.badge}</span>
              <small>{item.period}</small>
            </div>

            <div className="edu-body">
              <div className="edu-title-row">
                <h3>{item.title} <span>({item.short})</span></h3>
              </div>
              <p className="edu-school">🏫 {item.school}</p>
              <p className="edu-loc">📍 {item.location}</p>
              <p className="edu-note">{item.note}</p>
            </div>
          </article>
        ))}
      </div>

      {/* Certifications */}
      <div className="cert-section reveal">
        <h3 className="cert-heading">
          <span>✦</span> Certifications &amp; Courses
        </h3>
        <div className="cert-grid">
          {certifications.map((c) => (
            <div className={`cert-card cc-${c.color}`} key={c.name}>
              <span className="cert-icon">{c.icon}</span>
              <div>
                <p className="cert-name">{c.name}</p>
                <small className="cert-issuer">{c.issuer}</small>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

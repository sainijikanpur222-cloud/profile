import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Navbar.css';
import ThemeToggle from './ThemeToggle';

const links = [
  'Home',
  'About',
  'Skills',
  'Projects',
  'Education',
  'Contact',
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const nav = useNavigate();

  const go = (id) => {
    document
      .getElementById(id.toLowerCase())
      ?.scrollIntoView({ behavior: 'smooth' });

    setOpen(false);
  };

  const logout = () => {
    localStorage.removeItem('isLoggedIn');
    nav('/login');
  };

  return (
    <header className="nav">
      <a
        className="nav-brand"
        onClick={() => go('home')}
      >
        SHIVA<span>.</span>
      </a>

      <button
        className="menu"
        onClick={() => setOpen(!open)}
        aria-label="Toggle navigation"
      >
        {open ? '×' : '☰'}
      </button>

      <nav className={open ? 'open' : ''}>
        {links.map((x) => (
          <button
            key={x}
            onClick={() => go(x)}
          >
            {x}
          </button>
        ))}

        <div className="mobile-actions">
          <a href="#github">GitHub</a>
          <a href="#linkedin">LinkedIn</a>
        </div>
      </nav>

      <div className="nav-actions">
        <a href="#github" aria-label="GitHub">
          ◉
        </a>

        <a href="#linkedin" aria-label="LinkedIn">
          in
        </a>

        <ThemeToggle />

        <button
          className="logout"
          onClick={logout}
        >
          Logout <span>↗</span>
        </button>
      </div>
    </header>
  );
}
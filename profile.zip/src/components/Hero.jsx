import '../styles/Hero.css';
import profileImg from '../assets/profile.png';

export default function Hero() {
  return (
    <section id="home" className="hero section">

      {/* Profile Image - Top Center */}
      <div className="hero-profile-wrapper reveal">
        <div className="hero-profile-ring">
          <div className="hero-profile-glow" />
          <img
            src={profileImg}
            alt="Shiva Saini"
            className="hero-profile-img"
          />
          <div className="hero-profile-badge">
            <span className="badge-dot" />
            Available
          </div>
        </div>
      </div>

      <div className="hero-copy reveal">
        <span className="availability">
          <i /> Available for Opportunities
        </span>


        <p className="hello">HELLO, I’M</p>

        <h1>
          Shiva <span>Saini</span>
        </h1>

        <h2>
          BCA Student <em>&</em> Full Stack Developer
        </h2>

        <p className="hero-text">
          I build modern, responsive and user-focused web applications
          while continuously improving my development and problem-solving
          skills.
        </p>

        <div className="hero-cta">
          <a className="primary" href="#projects">
            View My Projects <b>↗</b>
          </a>

          <a className="secondary" href="#contact">
            Contact Me <b>→</b>
          </a>

          <a className="resume-btn" href="/resume.pdf" download="Shiva_Saini_Resume.pdf">
            Resume <b>⬇</b>
          </a>
        </div>

        <div className="hero-social">
          <span>Find me on</span>

          <a href="#github">GitHub ↗</a>

          <a href="in/shiva-saini-7a644938b">LinkedIn ↗</a>

          <a href="sainijikanpur222#gmail.com">Email ↗</a>
        </div>
      </div>

      <div className="developer-visual reveal">
        <div className="orbit orbit-a" />

        <div className="code-window">
          <div className="window-bar">
            <span />
            <span />
            <span />

            <p>developer.js</p>
          </div>

          <pre>
            <code>
              <i>const</i> developer = {'{'}
              {`\n`}
              {'  '}name: <b>"Shiva Saini"</b>,
              {`\n`}
              {'  '}role: <b>"Full Stack Developer"</b>,
              {`\n`}
              {'  '}passion: <b>"Building Web Apps"</b>
              {`\n`}
              {'}'};
            </code>
          </pre>

          <div className="code-line">
            <span>✦</span> creating thoughtful experiences
          </div>
        </div>

        <div className="float-card">
          <span className="spark">✦</span>

          <div>
            <small>CURRENTLY</small>
            <strong>Building & learning</strong>
          </div>
        </div>
      </div>
    </section>
  );
}
import { useRef, useState } from 'react';
import '../styles/Contact.css';

// ─── EmailJS config ────────────────────────────────
// Replace these with your actual values from emailjs.com
const EJ_SERVICE  = 'YOUR_SERVICE_ID';
const EJ_TEMPLATE = 'YOUR_TEMPLATE_ID';
const EJ_KEY      = 'YOUR_PUBLIC_KEY';
// ──────────────────────────────────────────────────

export default function Contact() {
  const formRef = useRef(null);
  const [form, setForm]     = useState({ name: '', email: '', message: '' });
  const [err, setErr]       = useState({});
  const [status, setStatus] = useState('idle'); // idle | sending | sent | error

  const validate = () => {
    const x = {};
    if (!form.name.trim())                     x.name    = 'Please enter your name.';
    if (!/^\S+@\S+\.\S+$/.test(form.email))   x.email   = 'Enter a valid email address.';
    if (!form.message.trim())                  x.message = 'Please write a message.';
    return x;
  };

  const submit = async (e) => {
    e.preventDefault();
    const errors = validate();
    setErr(errors);
    if (Object.keys(errors).length) return;

    setStatus('sending');
    try {
      // Uses window.emailjs loaded via CDN in index.html
      await window.emailjs.sendForm(EJ_SERVICE, EJ_TEMPLATE, formRef.current, EJ_KEY);
      setStatus('sent');
      setForm({ name: '', email: '', message: '' });
    } catch {
      setStatus('error');
    }
  };

  const field = (key, label, type = 'text') => (
    <label key={key}>
      {label}
      {type === 'textarea' ? (
        <textarea
          name={key}
          value={form[key]}
          onChange={(e) => setForm({ ...form, [key]: e.target.value })}
          rows="5"
        />
      ) : (
        <input
          type={type}
          name={key}
          value={form[key]}
          onChange={(e) => setForm({ ...form, [key]: e.target.value })}
        />
      )}
      {err[key] && <small className="error">{err[key]}</small>}
    </label>
  );

  return (
    <section id="contact" className="section contact">
      <div className="contact-copy reveal">
        <p className="eyebrow">GET IN TOUCH</p>
        <h2>Let's build something <span>together.</span></h2>
        <p>Have an idea or want to connect? Feel free to reach out — I reply fast.</p>

        <div className="contact-links">
          <a href="https://github.com/sainijikanpur222-cloud" target="_blank" rel="noreferrer">
            <b>◉</b> GitHub <span>↗</span>
          </a>
          <a href="https://www.linkedin.com/in/shiva-saini-7a644938b/" target="_blank" rel="noreferrer">
            <b>in</b> LinkedIn <span>↗</span>
          </a>
          <a href="sainijikanpur222@gmail.com">
            <b>@</b> Email <span>↗</span>
          </a>
        </div>
      </div>

      <form className="contact-form reveal" ref={formRef} onSubmit={submit} noValidate>
        {status === 'sent' ? (
          <div className="sent">
            <b>✦</b>
            <h3>Message sent!</h3>
            <p>Thanks for reaching out, Shiva will get back to you soon.</p>
            <button className="secondary" type="button" onClick={() => setStatus('idle')}>
              Send another
            </button>
          </div>
        ) : (
          <>
            {field('name',    'Your name')}
            {field('email',   'Email address', 'email')}
            {field('message', 'Message',       'textarea')}

            {status === 'error' && (
              <p className="error" style={{ marginBottom: 8 }}>
                Something went wrong. Please try again or email directly.
              </p>
            )}

            <button className="primary" disabled={status === 'sending'}>
              {status === 'sending' ? 'Sending…' : 'Send Message'} <b>↗</b>
            </button>
          </>
        )}
      </form>
    </section>
  );
}

import '../styles/About.css';
import useCountUp from '../hooks/useCountUp';

const focus = [
  ['01', 'Problem Solving',     'Breaking down complex ideas into clear, practical solutions.'],
  ['02', 'Web Development',     'Crafting responsive experiences with modern web technologies.'],
  ['03', 'Continuous Learning', 'Always exploring, improving and building what comes next.'],
  ['04', 'Adaptable Person',    'I quickly adapt to new environments, learn new technologies, and confidently take on new challenges.'],
];

const stats = [
  { target: 10, suffix: '+', label: 'Projects Built'    },
  { target: 12, suffix: '+', label: 'Technologies'      },
  { target: 200,suffix: '+', label: 'DSA Problems'      },
  { target: 100, suffix: '%', label: 'Learning Mindset' },
];

function StatItem({ target, suffix, label }) {
  const { count, ref } = useCountUp(target, 1600);
  return (
    <div ref={ref}>
      <strong>{count}{suffix}</strong>
      <span>{label}</span>
    </div>
  );
}

export default function About() {
  return (
    <section id="about" className="section about">
      <div className="section-head reveal">
        <p className="eyebrow">ABOUT ME</p>
        <h2>Turning ideas into <span>modern experiences.</span></h2>
      </div>

      <div className="about-grid">
        <p className="about-intro reveal">
          I am Shiva Saini, a BCA student passionate about software development,
          web technologies and problem solving. I enjoy building real-world
          applications and continuously improving my skills in frontend, backend
          and data structures.
        </p>

        <div className="focus-list">
          {focus.map(([n, t, d]) => (
            <article className="focus-card reveal" key={n}>
              <span>{n}</span>
              <div>
                <h3>{t}</h3>
                <p>{d}</p>
              </div>
              <b>↗</b>
            </article>
          ))}
        </div>
      </div>

      <div className="stats reveal">
        {stats.map((s) => (
          <StatItem key={s.label} {...s} />
        ))}
      </div>
    </section>
  );
}

import { useEffect, useRef } from 'react';

export default function Cursor() {
  const dot  = useRef(null);
  const ring = useRef(null);

  useEffect(() => {
    let mx = 0, my = 0; // mouse
    let rx = 0, ry = 0; // ring (lerped)
    let raf;

    const onMove = (e) => {
      mx = e.clientX;
      my = e.clientY;
      // dot follows instantly
      if (dot.current) {
        dot.current.style.left = mx + 'px';
        dot.current.style.top  = my + 'px';
      }
    };

    const lerp = (a, b, t) => a + (b - a) * t;

    const animate = () => {
      rx = lerp(rx, mx, 0.13);
      ry = lerp(ry, my, 0.13);
      if (ring.current) {
        ring.current.style.left = rx + 'px';
        ring.current.style.top  = ry + 'px';
      }
      raf = requestAnimationFrame(animate);
    };

    // hover effect on interactive elements
    const addHover = () => ring.current?.classList.add('hover');
    const remHover = () => ring.current?.classList.remove('hover');

    const interactives = document.querySelectorAll(
      'a, button, [role="button"], input, textarea, .skill-group, .project-card, .focus-card'
    );
    interactives.forEach((el) => {
      el.addEventListener('mouseenter', addHover);
      el.addEventListener('mouseleave', remHover);
    });

    document.addEventListener('mousemove', onMove);
    raf = requestAnimationFrame(animate);

    return () => {
      document.removeEventListener('mousemove', onMove);
      cancelAnimationFrame(raf);
      interactives.forEach((el) => {
        el.removeEventListener('mouseenter', addHover);
        el.removeEventListener('mouseleave', remHover);
      });
    };
  }, []);

  return (
    <>
      <div className="cursor-dot"  ref={dot}  />
      <div className="cursor-ring" ref={ring} />
    </>
  );
}

import '../styles/Skills.css';

const skillGroups = [
  {
    category: 'Languages',
    icon: '⌨',
    color: 'purple',
    skills: [
      { name: 'JavaScript', level: 85, tag: 'Primary' },
      { name: 'Java',       level: 75, tag: 'OOP'     },
      { name: 'C++',        level: 65, tag: 'Basics'  },
    ],
  },
  {
    category: 'Frontend',
    icon: '🎨',
    color: 'cyan',
    skills: [
      { name: 'React',   level: 80, tag: 'Main Framework' },
      { name: 'Angular', level: 60, tag: 'Learning'       },
      { name: 'HTML',    level: 95, tag: 'Expert'         },
      { name: 'CSS',     level: 90, tag: 'Expert'         },
    ],
  },
  {
    category: 'Backend',
    icon: '⚙',
    color: 'green',
    skills: [
      { name: 'Node.js',    level: 72, tag: 'Active'    },
      { name: 'Express.js', level: 70, tag: 'REST APIs' },
      { name: 'SQL',        level: 68, tag: 'Queries'   },
    ],
  },
  {
    category: 'Tools',
    icon: '🛠',
    color: 'yellow',
    skills: [
      { name: 'Git',    level: 82, tag: 'Daily Use' },
      { name: 'GitHub', level: 80, tag: 'Collab'   },
    ],
  },
];

function getLevelLabel(level) {
  if (level >= 90) return 'Expert';
  if (level >= 75) return 'Proficient';
  if (level >= 60) return 'Intermediate';
  return 'Learning';
}

export default function Skills() {
  return (
    <section id="skills" className="section skills">
      <div className="section-head center reveal">
        <p className="eyebrow">TOOLKIT</p>
        <h2>My <span>Skills</span></h2>
        <p>Tools I use to turn ideas into capable digital products.</p>
      </div>

      <div className="skills-groups">
        {skillGroups.map((group) => (
          <div className={`skill-group sg-${group.color} reveal`} key={group.category}>

            <div className="sg-header">
              <span className="sg-icon">{group.icon}</span>
              <h3>{group.category}</h3>
              <span className="sg-count">{group.skills.length} skills</span>
            </div>

            <div className="sg-skills">
              {group.skills.map(({ name, level, tag }) => (
                <div className="sk-row" key={name}>
                  <div className="sk-meta">
                    <span className="sk-name">{name}</span>
                    <span className="sk-tag">{tag}</span>
                    <span className="sk-pct">{level}%</span>
                  </div>
                  <div className="sk-bar-track">
                    <div
                      className="sk-bar-fill"
                      style={{ '--w': `${level}%` }}
                      data-label={getLevelLabel(level)}
                    />
                  </div>
                </div>
              ))}
            </div>

          </div>
        ))}
      </div>
    </section>
  );
}

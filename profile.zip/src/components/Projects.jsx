import '../styles/Projects.css';

const projects = [
  {
    num: '01',
    title: 'Smart Emergency Response System',
    desc: 'A smart ambulance optimization and hospital pre-admission system designed to improve emergency response coordination.',
    tags: ['React', 'Node.js', 'Express', 'MongoDB'],
    kind: 'emergency',
    icon: '✚',
    sub: 'EMERGENCY • CONNECTED',
    github: 'https://github.com/ShivaSaini',
    demo: '#',
  },
  {
    num: '02',
    title: 'Royal Enfield Website',
    desc: 'A modern responsive motorcycle website with bike listings, details and an attractive user interface.',
    tags: ['Angular', 'TypeScript', 'HTML', 'CSS'],
    kind: 'royal',
    icon: '◈',
    sub: 'MOTORCYCLES • EXPLORATION',
    github: 'https://github.com/ShivaSaini',
    demo: '#',
  },
  {
    num: '03',
    title: 'Weather Application',
    desc: 'A responsive weather application that displays real-time weather information using an external API.',
    tags: ['React', 'JavaScript', 'OpenWeather API'],
    kind: 'weather',
    icon: '☀',
    sub: 'WEATHER • LIVE DATA',
    github: 'https://github.com/ShivaSaini',
    demo: '#',
  },
  {
    num: '04',
    title: 'Job Portal',
    desc: 'A web application connecting job seekers and employers through a clean and responsive interface.',
    tags: ['Angular', 'JavaScript', 'HTML', 'CSS'],
    kind: 'job',
    icon: '⌘',
    sub: 'CAREERS • CONNECTION',
    github: 'https://github.com/ShivaSaini',
    demo: '#',
  },
];

export default function Projects() {
  return (
    <section id="projects" className="section projects">
      <div className="section-head reveal">
        <p className="eyebrow">SELECTED WORK</p>
        <h2>Featured <span>Projects</span></h2>
        <p>A selection of things I have built while learning and growing as a developer.</p>
      </div>

      <div className="project-grid">
        {projects.map(({ num, title, desc, tags, kind, icon, sub, github, demo }) => (
          <article className="project-card reveal" key={title}>
            <div className={`project-visual ${kind}`}>
              <span>{num}</span>
              <div className="visual-symbol">{icon}</div>
              <small>{sub}</small>
            </div>

            <div className="project-content">
              <h3>{title}</h3>
              <p>{desc}</p>

              <div className="tags">
                {tags.map((t) => <span key={t}>{t}</span>)}
              </div>

              <div className="project-links">
                <a href={demo} target="_blank" rel="noreferrer">
                  Live Demo <b>↗</b>
                </a>
                <a href={github} target="_blank" rel="noreferrer">
                  GitHub <b>↗</b>
                </a>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
